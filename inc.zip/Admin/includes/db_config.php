<?php

$db = new mysqli("localhost","root","","lms");


?>